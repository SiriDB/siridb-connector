'''SiriDB Default values

'''
DEFAULT_CLIENT_PORT = 9000