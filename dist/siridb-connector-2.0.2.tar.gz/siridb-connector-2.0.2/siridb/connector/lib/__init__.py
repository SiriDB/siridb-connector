'''SiriDB Connector - Communication with SiriDB

:copyright: 2016, Jeroen van der Heijden (Transceptor Technology)
:license: MIT
'''