'''SiriDB Connector - Communication with SiriDB

:copyright: 2017, Jeroen van der Heijden (Transceptor Technology)
:license: MIT
'''